import { useState } from "react";

export default function SoadBot() {
  const [messages, setMessages] = useState([
    { from: "bot", text: "Welcome to SOAD BOT SUPPORT ZONE — developed by SM Soad" },
  ]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;
    const userMsg = { from: "user", text: input };
    const botReply = { from: "bot", text: generateReply(input) };
    setMessages([...messages, userMsg, botReply]);
    setInput("");
  };

  const generateReply = (msg) => {
    if (msg.toLowerCase().includes("hello")) return "Hi! How can I assist you today?";
    if (msg.toLowerCase().includes("help")) return "Sure! I’m here to help. Ask me anything.";
    return "Interesting! Let me think about that...";
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>SOAD BOT</h1>
      <div style={{ height: 300, overflowY: "auto", border: "1px solid gray", padding: 10 }}>
        {messages.map((msg, i) => (
          <div key={i} style={{ textAlign: msg.from === "bot" ? "left" : "right", margin: 5 }}>
            <span style={{ background: msg.from === "bot" ? "#333" : "#0a0", padding: "6px 10px", borderRadius: 10 }}>
              {msg.text}
            </span>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 10 }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Type your message..."
          style={{ padding: 10, width: "70%" }}
        />
        <button onClick={handleSend} style={{ padding: 10, marginLeft: 10 }}>
          Send
        </button>
      </div>
    </div>
  );
}